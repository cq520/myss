<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model as EloquentMedel;

/**
 * Base Model
 */
class Model extends EloquentMedel
{
    public $timestamps = false;
}
